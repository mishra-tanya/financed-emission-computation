class EmissionCalculator:

    def __init__(self, loan, total_value):
        self.loan=float(loan)
        self.total_value=float(total_value)
    
    def financed_emission(self,value):
        if value is None:
            return 0.0
        emission = (self.loan/self.total_value) * float(value)
        return emission
    
    # def fuel_emission(self, fuels, factor):
    #     return sum(self.financed_emission(fuel*factor) for fuel in fuels if fuel is not None)
    
    def electricity_emission(self, electricity, unit_or_amount,industry_region):
          total_emission = 0

          amount_fuels = [
                    ["North America", 2],
                    ["Asia", 3],
                    ["Europe", 3],
               ]
          quantity_fuels = [
                    ["North America",3],
                    ["Asia",4],
                    ["Europe",2],
            ]
          
          if electricity is None or unit_or_amount not in ["Amount", "Quantity"] or not industry_region:
            return 0
          
          for i in range(3):

            if unit_or_amount is None or not industry_region:
                continue

            rows = amount_fuels if unit_or_amount == "Amount" else quantity_fuels
            print(rows,'efew')
            for row in rows:
                print('efelec',row[1])

                if row[0] != industry_region or len(row) < 2:
                    continue

                try:
                    scope1 = float(row[1])
                    total_emission += self.financed_emission(scope1 * float(electricity)) 
                except Exception as e:
                    print(f"Error in fuel_{i + 1} row {row}: {e}")
                    continue

            return total_emission

        # return self.financed_emission(electricity * factor) if electricity is not None else 0.0
    
    @staticmethod
    def format_or_na(value):
        return "{:.4f}".format(value) if isinstance(value, (int, float)) else "NA"
    
    @staticmethod
    def prepare_industry_sector_factor(sector):
        return {
            "Steel": 2.5,
            "Aluminium": 1.7,
            "Thermal": 10,
            "Solar": 0.1,
        }.get(sector, 1)
    
    def fuel_emission(self, fuels, quantity_or_amount, industry_region):
        total_emission = 0

        amount_fuels = {
            "fuel_1": [
                ["North America", 7],
                ["Asia", 5],
                ["Europe",8 ],
            ],
            "fuel_2": [
                ["North America", 5],
                ["Asia", 6],
                ["Europe", 4],
            ],
            "fuel_3": [
                ["North America", 9],
                ["Asia", 9],
                ["Europe", 10],
            ]
        }

        quantity_fuels = {
            "fuel_1": [
                ["North America", 30],
                ["Asia", 2],
                ["Europe", 33],
            ],
            "fuel_2": [
                ["North America", 25],
                ["Asia", 8],
                ["Europe", 23],
            ],
            "fuel_3": [
                ["North America", 45],
                ["Asia", 3],
                ["Europe",23],
            ]
        }

        for i in range(3):
            fuel_key = fuels[i] if i < len(fuels) else None
            quantity_mode = quantity_or_amount[i] if i < len(quantity_or_amount) else None

            if not fuel_key or not quantity_mode or not industry_region:
                continue

            try:
                fuel_key = float(fuel_key)
            except:
                continue 
            
            print(fuel_key, "fuel_key")
            print(quantity_mode, "quantity_mode")

            data_source = amount_fuels if quantity_mode == "Amount" else quantity_fuels
            print("data",data_source)
            rows = data_source.get(f"fuel_{i+1}", [])
            print(data_source.get(f"fuel_{i+1}", []),"efie")
            print(rows,'efew')
            for row in rows:
                print('ef',row[1])

                if row[0] != industry_region or len(row) < 1:
                    continue

                try:
                    scope1 = float(row[1])
                    total_emission += self.financed_emission(scope1 * float(fuel_key)) 
                except Exception as e:
                    print(f"Error in fuel_{i + 1} row {row}: {e}")
                    continue

        return total_emission


    def assetbased(self, industry_region, sector):
        emission_1 = 0
        emission_2 = 0

        steel = {
            "North America": [23, 34],
            "Asia": [33, 32],
            "Europe": [43, 53],
        }

        aluminium = {
            "North America": [10, 20],
            "Asia": [5, 15],
            "Europe": [8, 18],
        }

        thermal = {
            "North America": [12, 22],
            "Asia": [6, 16],
            "Europe": [9, 19],
        }

        solar = {
            "North America": [2, 3],
            "Asia": [1, 2],
            "Europe": [1.5, 2.5],
        }

        if sector.lower() == "steel":
            data = steel
        elif sector.lower() == "aluminium":
            data = aluminium
        elif sector.lower() == "thermal":
            data = thermal
        elif sector.lower() == "solar":
            data = solar
        else:
            return 0, 0  

        values = data.get(industry_region)
        if values and len(values) >= 2:
            emission_1 = self.financed_emission(float(values[0]))
            emission_2 = self.financed_emission(float(values[1]))

        return emission_1, emission_2
